void rnd_init(unsigned long);
unsigned long rnd_long(void);
unsigned long rnd_1279(void);
double rnd_double(void);
unsigned long rnd69069(void);
unsigned long rnd127(void);
double gaussian(double);
