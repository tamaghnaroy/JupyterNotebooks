void sing(double *, double *, long, int);
void  realtr(double *, double *, long, int);
